
    chrome.runtime.onInstalled.addListener(() => {
        var config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "pr.oxylabs.io",
                    port: parseInt(7777)
                },
                bypassList: ["localhost"]
            }
        };
        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    });

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "umar_lfy_Boeun",
                    password: "umar_LFY1234"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    